export const etc = {
  maxLimit: 100,
  minLimit: 1,
  defaultLimit: 10,
  defaultPage: 0,
};
