Instructions: 
1. Go to the terminal and enter commands 
To generate migration...
npm run migration:generate -- db/migrations/inital

To run migration....
npm run migration:run --d dist/database/data-source.js

To run seeds....
npm run seed